module.exports.Account = require('./Account.js');
module.exports.Pokemon = require('./Pokemon.js');
